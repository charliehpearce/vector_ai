# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['kafka_pubsub']

package_data = \
{'': ['*']}

install_requires = \
['google-cloud-pubsub>=2.8.0,<3.0.0', 'kafka-python>=2.0.2,<3.0.0']

setup_kwargs = {
    'name': 'kafka-pubsub',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Charles H J Pearce',
    'author_email': 'charleshjpearce@Charless-MacBook-Pro.local',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
